package com.luxitec.controller;

import com.luxitec.bean.LocalizacionBean;
import com.luxitec.bean.UsuarioBean;

public class MovegoMessage {

	public static final String COMMAND_LOCALIZACION="0";
	public static final String COMMAND_CONFIRMAR_SOLICITUD="1";
	public static final String COMMAND_SOLICITUD="2";
	
	private String command;
	private String mensaje;
	private String error;
	private UsuarioBean usuario;
	private LocalizacionBean localizacion;
	
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public UsuarioBean getUsuario() {
		return usuario;
	}
	public void setUsuario(UsuarioBean usuario) {
		this.usuario = usuario;
	}
	public LocalizacionBean getLocalizacion() {
		return localizacion;
	}
	public void setLocalizacion(LocalizacionBean localizacion) {
		this.localizacion = localizacion;
	}
	
	
	
	
}
