package com.luxitec.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.luxitec.bean.UsuarioBean;
import com.luxitec.service.IntegradorService;

@Controller
@CrossOrigin(origins = "http://localhost:8080", maxAge = 3600)
@RequestMapping("")
public class MoveGoIntegrationController {

	@Autowired
	private IntegradorService integradorService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET, produces = {"application/json;charset=utf-8", "text/json;charset=utf-8" })	
	public @ResponseBody String hola() {
		System.out.println("entra");
		return "Hola";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = {"application/json;charset=utf-8", "text/json;charset=utf-8" })	
	public @ResponseBody UsuarioBean login(UsuarioBean u) {
		u = integradorService.login(u); 
		return u;
	}

	@MessageMapping("/movego_ws")
	@SendTo("/topic/resultconnect")
	public MovegoResult resultconnect(MovegoMessage message) throws Exception {
		MovegoResult r = null;
		String c = message.getCommand();
		System.out.println("resultconnect");
		System.out.println(c);
		System.out.println(message.getMensaje());
		System.out.println(message.getUsuario());
		System.out.println(message.getLocalizacion());
		if (c != null) {
			switch (c) {
			case MovegoMessage.COMMAND_LOCALIZACION:
				System.out.println("COMMAND_LOCALIZACION");
				r = integradorService.registrarLocalizacion(message.getUsuario(),message.getLocalizacion());
				break;
			case MovegoMessage.COMMAND_SOLICITUD:
				System.out.println("COMMAND_SOLICITUD");

				break;
			case MovegoMessage.COMMAND_CONFIRMAR_SOLICITUD:
				System.out.println("COMMAND_CONFIRMAR_SOLICITUD");

				break;

			}
		}

		return r;
	}
	

//	private TaskScheduler scheduler = new ConcurrentTaskScheduler();
//	@PostConstruct
//	private void broadcastTimePeriodically() {
//		System.out.println("broadcastTimePeriodically");
//		// scheduler.scheduleAtFixedRate(new Runnable() {
//		// @Override
//		// public void run() {
//		// updatelista(null);
//		// }
//		// }, 1000);
//	}

	// private void updatelista(UsuarioBean u ) {
	// System.out.println("updatelista");
	// System.out.println(listaUsuarioOnline);
	// System.out.println(u);
	// if(u!=null){
	// if(u.isConnect()){
	// listaUsuarioOnline.add(u);
	// }else{
	// listaUsuarioOnline.remove(u);
	// }
	// }
	// }

}