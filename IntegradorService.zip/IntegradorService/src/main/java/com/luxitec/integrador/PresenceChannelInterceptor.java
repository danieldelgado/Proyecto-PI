package com.luxitec.integrador;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptorAdapter;

public class PresenceChannelInterceptor extends ChannelInterceptorAdapter {

	private final Log logger = LogFactory.getLog(PresenceChannelInterceptor.class);

	@Override
	public void postSend(Message<?> message, MessageChannel channel, boolean sent) {
		System.out.println("postSend");
		StompHeaderAccessor sha = StompHeaderAccessor.wrap(message);
		System.out.println("getCommand:" + sha.getCommand());
		if (sha.getCommand() == null) {
			return;
		}
		String sessionId = sha.getSessionId();
		System.out.println("getLogin:" + sha.getLogin());
		System.out.println("getPasscode:" + sha.getPasscode());
		switch (sha.getCommand()) {
		case CONNECT:
			System.out.println("STOMP Connect [sessionId: " + sessionId + "]");
			break;
		case CONNECTED:
			System.out.println("STOMP Connected [sessionId: " + sessionId + "]");
			break;
		case DISCONNECT:
			System.out.println("STOMP Disconnect [sessionId: " + sessionId + "]");
			break;
		case SUBSCRIBE:
			System.out.println("STOMP SUBSCRIBE [sessionId: " + sessionId + "]");
			break;
		case UNSUBSCRIBE:
			System.out.println("STOMP UNSUBSCRIBE [sessionId: " + sessionId + "]");
			break;
		case SEND:
			System.out.println("STOMP SEND [sessionId: " + sessionId + "]");
			break;
		}
	}
}